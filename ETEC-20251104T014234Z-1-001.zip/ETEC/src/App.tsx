import { Header } from './components/Header'
import { Navigation } from './components/Navigation'
import { Hero } from './components/Hero'
import { Features } from './components/Features'
import { ProductCatalog } from './components/ProductCatalog'
import { Footer } from './components/Footer'
import { ShoppingCart } from './components/ShoppingCart'

function App() {
  console.log('ETEC WEAVE E-commerce App initialized')
  
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Navigation />
      <Hero />
      <Features />
      <div id="produtos">
        <ProductCatalog />
      </div>
      <Footer />
      <ShoppingCart />
    </div>
  )
}

export default App