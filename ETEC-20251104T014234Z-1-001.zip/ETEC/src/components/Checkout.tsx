import React, { useState } from 'react';
import { ArrowLeft, CreditCard, Truck, MapPin, User, Mail, Phone, Calendar, Lock } from 'lucide-react';
import { useCartStore } from '../stores/cartStore';
import { useUserStore } from '../stores/userStore';

interface CheckoutProps {
  isOpen: boolean;
  onClose: () => void;
}

export function Checkout({ isOpen, onClose }: CheckoutProps) {
  const { items, getTotalPrice, clearCart } = useCartStore();
  const { user, isLoggedIn } = useUserStore();
  
  const [currentStep, setCurrentStep] = useState(1);
  const [shippingData, setShippingData] = useState({
    fullName: user?.name || '',
    email: user?.email || '',
    phone: '',
    cep: '',
    address: '',
    number: '',
    complement: '',
    neighborhood: '',
    city: '',
    state: '',
  });
  
  const [paymentData, setPaymentData] = useState({
    method: 'credit',
    cardNumber: '',
    cardName: '',
    expiryDate: '',
    cvv: '',
    installments: '1',
  });

  const [shippingMethod, setShippingMethod] = useState('standard');

  console.log('Checkout rendered:', { isOpen, currentStep, totalItems: items.length });

  if (!isOpen) return null;

  const shipping = getTotalPrice() >= 100 ? 0 : 15.90;
  const discount = paymentData.method === 'pix' ? getTotalPrice() * 0.05 : 0;
  const finalTotal = getTotalPrice() + shipping - discount;

  const handleShippingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Shipping data submitted:', shippingData);
    setCurrentStep(2);
  };

  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Payment data submitted:', paymentData);
    setCurrentStep(3);
  };

  const handleOrderConfirmation = () => {
    console.log('Order confirmed:', {
      items,
      shipping: shippingData,
      payment: paymentData,
      total: finalTotal
    });
    
    alert('Pedido realizado com sucesso! Você receberá um email com os detalhes.');
    clearCart();
    onClose();
    setCurrentStep(1);
  };

  const formatCurrency = (value: number) => {
    return `R$ ${value.toFixed(2).replace('.', ',')}`;
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black bg-opacity-50">
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
          {/* Header */}
          <div className="bg-etec-orange p-6 flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={currentStep > 1 ? () => setCurrentStep(currentStep - 1) : onClose}
                className="text-white hover:bg-black hover:bg-opacity-20 p-2 rounded-md transition-colors"
              >
                <ArrowLeft className="w-6 h-6" />
              </button>
              <h1 className="text-2xl font-bold text-white">Finalizar Compra</h1>
            </div>
            
            {/* Progress Steps */}
            <div className="flex items-center space-x-4">
              {[1, 2, 3].map((step) => (
                <div
                  key={step}
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                    step <= currentStep
                      ? 'bg-white text-etec-orange'
                      : 'bg-black bg-opacity-20 text-white'
                  }`}
                >
                  {step}
                </div>
              ))}
            </div>
          </div>

          <div className="flex flex-col lg:flex-row">
            {/* Main Content */}
            <div className="flex-1 p-6">
              {currentStep === 1 && (
                <form onSubmit={handleShippingSubmit} className="space-y-6">
                  <div>
                    <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
                      <Truck className="w-6 h-6 mr-2 text-etec-orange" />
                      Dados de Entrega
                    </h2>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Nome Completo
                        </label>
                        <input
                          type="text"
                          required
                          value={shippingData.fullName}
                          onChange={(e) => setShippingData({ ...shippingData, fullName: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-etec-orange focus:border-transparent"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          E-mail
                        </label>
                        <input
                          type="email"
                          required
                          value={shippingData.email}
                          onChange={(e) => setShippingData({ ...shippingData, email: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-etec-orange focus:border-transparent"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Telefone
                        </label>
                        <input
                          type="tel"
                          required
                          value={shippingData.phone}
                          onChange={(e) => setShippingData({ ...shippingData, phone: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-etec-orange focus:border-transparent"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          CEP
                        </label>
                        <input
                          type="text"
                          required
                          value={shippingData.cep}
                          onChange={(e) => setShippingData({ ...shippingData, cep: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-etec-orange focus:border-transparent"
                        />
                      </div>
                      
                      <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Endereço
                        </label>
                        <input
                          type="text"
                          required
                          value={shippingData.address}
                          onChange={(e) => setShippingData({ ...shippingData, address: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-etec-orange focus:border-transparent"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Número
                        </label>
                        <input
                          type="text"
                          required
                          value={shippingData.number}
                          onChange={(e) => setShippingData({ ...shippingData, number: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-etec-orange focus:border-transparent"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Complemento
                        </label>
                        <input
                          type="text"
                          value={shippingData.complement}
                          onChange={(e) => setShippingData({ ...shippingData, complement: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-etec-orange focus:border-transparent"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Bairro
                        </label>
                        <input
                          type="text"
                          required
                          value={shippingData.neighborhood}
                          onChange={(e) => setShippingData({ ...shippingData, neighborhood: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-etec-orange focus:border-transparent"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Cidade
                        </label>
                        <input
                          type="text"
                          required
                          value={shippingData.city}
                          onChange={(e) => setShippingData({ ...shippingData, city: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-etec-orange focus:border-transparent"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Estado
                        </label>
                        <select
                          required
                          value={shippingData.state}
                          onChange={(e) => setShippingData({ ...shippingData, state: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-etec-orange focus:border-transparent"
                        >
                          <option value="">Selecione o estado</option>
                          <option value="SP">São Paulo</option>
                          <option value="RJ">Rio de Janeiro</option>
                          <option value="MG">Minas Gerais</option>
                          <option value="RS">Rio Grande do Sul</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  {/* Shipping Method */}
                  <div>
                    <h3 className="text-lg font-semibold text-gray-800 mb-3">
                      Método de Entrega
                    </h3>
                    <div className="space-y-2">
                      <label className="flex items-center p-3 border rounded-md hover:bg-gray-50 cursor-pointer">
                        <input
                          type="radio"
                          name="shipping"
                          value="standard"
                          checked={shippingMethod === 'standard'}
                          onChange={(e) => setShippingMethod(e.target.value)}
                          className="mr-3"
                        />
                        <div className="flex-1">
                          <div className="font-medium">Entrega Padrão</div>
                          <div className="text-sm text-gray-600">5-7 dias úteis</div>
                        </div>
                        <div className="font-semibold text-etec-orange">
                          {getTotalPrice() >= 100 ? 'Grátis' : 'R$ 15,90'}
                        </div>
                      </label>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-etec-orange text-white py-3 rounded-md hover:bg-orange-600 transition-colors font-medium"
                  >
                    Continuar para Pagamento
                  </button>
                </form>
              )}

              {currentStep === 2 && (
                <form onSubmit={handlePaymentSubmit} className="space-y-6">
                  <div>
                    <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
                      <CreditCard className="w-6 h-6 mr-2 text-etec-orange" />
                      Método de Pagamento
                    </h2>
                    
                    <div className="space-y-4">
                      <label className="flex items-center p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                        <input
                          type="radio"
                          name="payment"
                          value="credit"
                          checked={paymentData.method === 'credit'}
                          onChange={(e) => setPaymentData({ ...paymentData, method: e.target.value })}
                          className="mr-3"
                        />
                        <CreditCard className="w-6 h-6 mr-3 text-gray-600" />
                        <div>
                          <div className="font-medium">Cartão de Crédito</div>
                          <div className="text-sm text-gray-600">Em até 12x sem juros</div>
                        </div>
                      </label>
                      
                      <label className="flex items-center p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                        <input
                          type="radio"
                          name="payment"
                          value="pix"
                          checked={paymentData.method === 'pix'}
                          onChange={(e) => setPaymentData({ ...paymentData, method: e.target.value })}
                          className="mr-3"
                        />
                        <div className="w-6 h-6 mr-3 bg-green-500 rounded flex items-center justify-center text-white font-bold text-xs">
                          PIX
                        </div>
                        <div>
                          <div className="font-medium">PIX</div>
                          <div className="text-sm text-green-600">5% de desconto à vista</div>
                        </div>
                      </label>
                    </div>
                    
                    {paymentData.method === 'credit' && (
                      <div className="mt-6 space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Número do Cartão
                          </label>
                          <input
                            type="text"
                            required
                            value={paymentData.cardNumber}
                            onChange={(e) => setPaymentData({ ...paymentData, cardNumber: e.target.value })}
                            placeholder="0000 0000 0000 0000"
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-etec-orange focus:border-transparent"
                          />
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Nome no Cartão
                          </label>
                          <input
                            type="text"
                            required
                            value={paymentData.cardName}
                            onChange={(e) => setPaymentData({ ...paymentData, cardName: e.target.value })}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-etec-orange focus:border-transparent"
                          />
                        </div>
                        
                        <div className="grid grid-cols-3 gap-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Vencimento
                            </label>
                            <input
                              type="text"
                              required
                              value={paymentData.expiryDate}
                              onChange={(e) => setPaymentData({ ...paymentData, expiryDate: e.target.value })}
                              placeholder="MM/AA"
                              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-etec-orange focus:border-transparent"
                            />
                          </div>
                          
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              CVV
                            </label>
                            <input
                              type="text"
                              required
                              value={paymentData.cvv}
                              onChange={(e) => setPaymentData({ ...paymentData, cvv: e.target.value })}
                              placeholder="123"
                              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-etec-orange focus:border-transparent"
                            />
                          </div>
                          
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Parcelas
                            </label>
                            <select
                              value={paymentData.installments}
                              onChange={(e) => setPaymentData({ ...paymentData, installments: e.target.value })}
                              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-etec-orange focus:border-transparent"
                            >
                              {[...Array(12)].map((_, i) => (
                                <option key={i + 1} value={i + 1}>
                                  {i + 1}x {formatCurrency(finalTotal / (i + 1))}
                                </option>
                              ))}
                            </select>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-etec-orange text-white py-3 rounded-md hover:bg-orange-600 transition-colors font-medium"
                  >
                    Revisar Pedido
                  </button>
                </form>
              )}

              {currentStep === 3 && (
                <div className="space-y-6">
                  <div>
                    <h2 className="text-xl font-semibold text-gray-800 mb-4">
                      Confirmar Pedido
                    </h2>
                    
                    <div className="bg-gray-50 rounded-lg p-4 space-y-4">
                      <div>
                        <h3 className="font-medium text-gray-800">Entrega</h3>
                        <p className="text-sm text-gray-600">
                          {shippingData.fullName}<br />
                          {shippingData.address}, {shippingData.number}<br />
                          {shippingData.neighborhood}, {shippingData.city} - {shippingData.state}<br />
                          CEP: {shippingData.cep}
                        </p>
                      </div>
                      
                      <div>
                        <h3 className="font-medium text-gray-800">Pagamento</h3>
                        <p className="text-sm text-gray-600">
                          {paymentData.method === 'credit' 
                            ? `Cartão de Crédito - ${paymentData.installments}x`
                            : 'PIX (5% de desconto)'
                          }
                        </p>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={handleOrderConfirmation}
                    className="w-full bg-etec-orange text-white py-4 rounded-md hover:bg-orange-600 transition-colors font-medium text-lg"
                  >
                    Finalizar Pedido - {formatCurrency(finalTotal)}
                  </button>
                </div>
              )}
            </div>

            {/* Order Summary Sidebar */}
            <div className="lg:w-96 bg-gray-50 p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Resumo do Pedido</h3>
              
              <div className="space-y-4">
                {items.map((item, index) => (
                  <div key={`${item.product.id}-${item.size}-${item.color}`} className="flex items-start space-x-3">
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-12 h-12 object-cover rounded-md"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm font-medium text-gray-800 truncate">
                        {item.product.name}
                      </h4>
                      <p className="text-xs text-gray-600">
                        {item.size} • {item.color} • Qtd: {item.quantity}
                      </p>
                      <p className="text-sm font-semibold text-etec-orange">
                        {formatCurrency(item.product.price * item.quantity)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="mt-6 pt-4 border-t space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Subtotal</span>
                  <span>{formatCurrency(getTotalPrice())}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Frete</span>
                  <span>{shipping > 0 ? formatCurrency(shipping) : 'Grátis'}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-sm text-green-600">
                    <span>Desconto PIX (5%)</span>
                    <span>-{formatCurrency(discount)}</span>
                  </div>
                )}
                <div className="flex justify-between text-lg font-semibold text-gray-800 pt-2 border-t">
                  <span>Total</span>
                  <span className="text-etec-orange">{formatCurrency(finalTotal)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}