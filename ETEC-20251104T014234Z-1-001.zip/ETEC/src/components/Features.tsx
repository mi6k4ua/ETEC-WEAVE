import React from 'react';
import { Truck, Shield, CreditCard, HeadphonesIcon, RotateCcw, Star } from 'lucide-react';

export function Features() {
  console.log('Features section rendered');

  const features = [
    {
      icon: Truck,
      title: 'Frete Grátis',
      description: 'Frete grátis para compras acima de R$ 100,00 em todo o Brasil'
    },
    {
      icon: Shield,
      title: 'Compra Segura',
      description: 'Seus dados protegidos com certificado SSL e criptografia avançada'
    },
    {
      icon: CreditCard,
      title: 'Pagamento Flexível',
      description: 'Pague no cartão em até 12x sem juros ou no PIX com 5% de desconto'
    },
    {
      icon: HeadphonesIcon,
      title: 'Suporte 24/7',
      description: 'Atendimento especializado disponível todos os dias da semana'
    },
    {
      icon: RotateCcw,
      title: 'Troca Fácil',
      description: 'Não ficou satisfeito? Troque ou devolva em até 30 dias'
    },
    {
      icon: Star,
      title: 'Qualidade Premium',
      description: 'Produtos de alta qualidade com garantia de durabilidade'
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-4">Por que escolher a ETEC WEAVE?</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Oferecemos mais do que uniformes - proporcionamos uma experiência completa de compra
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div key={index} className="text-center p-6 rounded-lg hover:shadow-lg transition-shadow duration-300">
                <div className="w-16 h-16 bg-etec-orange bg-opacity-10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Icon className="w-8 h-8 text-etec-orange" />
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-3">{feature.title}</h3>
                <p className="text-gray-600 leading-relaxed">{feature.description}</p>
              </div>
            );
          })}
        </div>

        <div className="mt-16 bg-gradient-to-r from-etec-orange to-orange-600 rounded-2xl text-white p-8 text-center">
          <h3 className="text-2xl font-bold mb-4">Seja parte da comunidade ETEC WEAVE</h3>
          <p className="text-lg mb-6 opacity-90">
            Mais de 10.000 estudantes já confiam em nossos uniformes
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
            <div>
              <div className="text-3xl font-bold">10K+</div>
              <div className="text-sm opacity-80">Estudantes Satisfeitos</div>
            </div>
            <div>
              <div className="text-3xl font-bold">50+</div>
              <div className="text-sm opacity-80">Escolas Parceiras</div>
            </div>
            <div>
              <div className="text-3xl font-bold">4.9★</div>
              <div className="text-sm opacity-80">Avaliação Média</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}