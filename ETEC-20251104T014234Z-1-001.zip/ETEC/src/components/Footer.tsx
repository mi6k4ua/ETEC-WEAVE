import React from 'react';
import { Facebook, Instagram, Twitter, Youtube, Mail, Phone, MapPin } from 'lucide-react';

export function Footer() {
  console.log('Footer component rendered');

  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <div className="text-etec-orange font-bold text-2xl leading-tight">
              <div>ETEC</div>
              <div>WEAVE</div>
            </div>
            <p className="text-gray-300">
              Seu uniforme, sua identidade. Qualidade e conforto para estudantes de todo o Brasil.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-etec-orange transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-etec-orange transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-etec-orange transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-etec-orange transition-colors">
                <Youtube className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Products */}
          <div>
            <h3 className="font-semibold text-lg mb-4">Produtos</h3>
            <ul className="space-y-2">
              <li><a href="#camisas" className="text-gray-300 hover:text-etec-orange transition-colors">Camisas</a></li>
              <li><a href="#jaquetas" className="text-gray-300 hover:text-etec-orange transition-colors">Jaquetas</a></li>
              <li><a href="#calcas" className="text-gray-300 hover:text-etec-orange transition-colors">Calças</a></li>
              <li><a href="#jalecos" className="text-gray-300 hover:text-etec-orange transition-colors">Jalecos</a></li>
              <li><a href="#" className="text-gray-300 hover:text-etec-orange transition-colors">Acessórios</a></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="font-semibold text-lg mb-4">Suporte</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-300 hover:text-etec-orange transition-colors">Central de Ajuda</a></li>
              <li><a href="#" className="text-gray-300 hover:text-etec-orange transition-colors">Política de Troca</a></li>
              <li><a href="#" className="text-gray-300 hover:text-etec-orange transition-colors">Guia de Tamanhos</a></li>
              <li><a href="#" className="text-gray-300 hover:text-etec-orange transition-colors">Rastreamento</a></li>
              <li><a href="#" className="text-gray-300 hover:text-etec-orange transition-colors">Fale Conosco</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-semibold text-lg mb-4">Contato</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-etec-orange" />
                <span className="text-gray-300">(11) 99999-9999</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-etec-orange" />
                <span className="text-gray-300">contato@etecweave.com</span>
              </div>
              <div className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 text-etec-orange mt-1" />
                <span className="text-gray-300">
                  Rua das Escolas, 123<br />
                  São Paulo - SP<br />
                  CEP: 01234-567
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2025 ETEC WEAVE. Todos os direitos reservados.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-etec-orange text-sm transition-colors">
                Política de Privacidade
              </a>
              <a href="#" className="text-gray-400 hover:text-etec-orange text-sm transition-colors">
                Termos de Uso
              </a>
              <a href="#" className="text-gray-400 hover:text-etec-orange text-sm transition-colors">
                Cookies
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}