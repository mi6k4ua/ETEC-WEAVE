import React from 'react'

export function Header() {
  console.log('Header component rendered')
  
  return (
    <header className="bg-etec-purple text-white py-3">
      <div className="container mx-auto px-4">
        <div className="text-center">
          <p className="text-sm font-medium">
            Promoção! 25% de desconto em todo site usando o cupom TEES25
          </p>
        </div>
      </div>
    </header>
  )
}