import React from 'react'

export function Hero() {
  console.log('Hero component rendered')
  
  return (
    <section className="relative h-screen overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-hero-pattern bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=1920&h=1080&fit=crop&crop=center')"
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-10"></div>
      </div>
      
      {/* Content */}
      <div className="relative z-10 flex items-center justify-center h-full">
        <div className="text-center">
          <h1 className="text-6xl md:text-8xl font-black text-black mb-8 leading-none">
            <div>ETEC</div>
            <div>WEAVE</div>
          </h1>
          
          <div className="bg-etec-orange px-8 py-4 inline-block">
            <p className="text-black font-bold text-lg leading-tight">
              Seu uniforme, sua identidade.<br />
              Compre com praticidade!
            </p>
          </div>
        </div>
      </div>
      
      {/* Chat Widget Placeholder */}
      <div className="fixed bottom-6 right-6 w-16 h-16 bg-gray-800 rounded-full flex items-center justify-center shadow-lg">
        <div className="w-6 h-6 bg-white rounded-sm"></div>
      </div>
    </section>
  )
}