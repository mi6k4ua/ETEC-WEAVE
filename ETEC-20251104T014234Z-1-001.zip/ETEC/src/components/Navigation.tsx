import React from 'react';
import { ShoppingCart } from 'lucide-react';
import { useCartStore } from '../stores/cartStore';
import { UserProfile } from './UserProfile';

export function Navigation() {
  const { toggleCart, getTotalItems } = useCartStore();
  
  console.log('Navigation component rendered with cart items:', getTotalItems());
  
  const menuItems = [
    { label: 'Camisas', category: 'camisas' },
    { label: 'Jaquetas', category: 'jaquetas' },
    { label: 'Calças', category: 'calcas' },
    { label: 'Jalecos', category: 'jalecos' }
  ];
  
  const scrollToProducts = (category?: string) => {
    console.log('Scrolling to products section with category:', category);
    
    // Primeiro, rola até a seção de produtos
    const element = document.querySelector('#produtos');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    
    // Depois dispara evento customizado para filtrar por categoria
    if (category) {
      setTimeout(() => {
        window.dispatchEvent(new CustomEvent('filterByCategory', { 
          detail: { category } 
        }));
      }, 500);
    }
  };
  
  return (
    <nav className="bg-etec-orange shadow-lg sticky top-0 z-40">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex-shrink-0">
            <div className="text-black font-bold text-xl leading-tight cursor-pointer"
                 onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
              <div>ETEC</div>
              <div>WEAVE</div>
            </div>
          </div>
          
          {/* Menu Items */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-1">
              {menuItems.map((item) => (
                <button
                  key={item.label}
                  onClick={() => scrollToProducts(item.category)}
                  className="text-black hover:bg-black hover:text-etec-orange px-6 py-4 text-sm font-medium transition-colors duration-200 border-r border-black last:border-r-0"
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
          
          {/* User Menu & Cart */}
          <div className="flex items-center space-x-4">
            <UserProfile />
            
            <button
              onClick={toggleCart}
              className="relative p-2 text-black hover:bg-black hover:text-etec-orange rounded-md transition-colors"
            >
              <ShoppingCart className="w-6 h-6" />
              {getTotalItems() > 0 && (
                <span className="absolute -top-1 -right-1 bg-etec-purple text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-medium">
                  {getTotalItems()}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}