import React, { useState } from 'react';
import { X, ShoppingCart, Heart, Share2, Star } from 'lucide-react';
import { Product } from '../types/product';
import { useCartStore } from '../stores/cartStore';

interface ProductModalProps {
  product: Product;
  isOpen: boolean;
  onClose: () => void;
}

export function ProductModal({ product, isOpen, onClose }: ProductModalProps) {
  const [selectedSize, setSelectedSize] = useState(product.sizes[0]);
  const [selectedColor, setSelectedColor] = useState(product.colors[0]);
  const [quantity, setQuantity] = useState(1);
  const addItem = useCartStore((state) => state.addItem);

  console.log('Product modal opened:', { product: product.name, selectedSize, selectedColor });

  if (!isOpen) return null;

  const handleAddToCart = () => {
    console.log('Adding to cart from modal:', { product: product.name, selectedSize, selectedColor, quantity });
    addItem(product, selectedSize, selectedColor, quantity);
    onClose();
  };

  const getColorStyle = (color: string) => {
    const colorMap: { [key: string]: string } = {
      'Branco': '#FFFFFF',
      'Preto': '#000000',
      'Laranja': '#FF5722',
      'Azul': '#2196F3',
      'Azul Marinho': '#1A237E',
      'Azul Claro': '#81D4FA',
      'Cinza': '#9E9E9E',
      'Rosa': '#E91E63',
      'Rosa Claro': '#F8BBD9',
      'Marinho': '#1A237E',
    };
    return colorMap[color] || '#FF5722';
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
        <div className="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75" onClick={onClose}></div>

        <div className="inline-block w-full max-w-4xl p-6 my-8 overflow-hidden text-left align-middle transition-all transform bg-white shadow-xl rounded-2xl">
          <div className="flex justify-between items-start mb-6">
            <h2 className="text-2xl font-bold text-gray-900">{product.name}</h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Product Image */}
            <div className="space-y-4">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-96 object-cover rounded-lg"
              />
              <div className="flex space-x-2">
                {[1, 2, 3].map((i) => (
                  <img
                    key={i}
                    src={product.image}
                    alt={`${product.name} ${i}`}
                    className="w-20 h-20 object-cover rounded-md border-2 border-gray-200 hover:border-etec-orange cursor-pointer transition-colors opacity-75"
                  />
                ))}
              </div>
            </div>

            {/* Product Details */}
            <div className="space-y-6">
              <div>
                <div className="flex items-center space-x-2 mb-2">
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="w-5 h-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <span className="text-sm text-gray-600">(128 avaliações)</span>
                </div>
                <p className="text-3xl font-bold text-etec-orange mb-4">
                  R$ {product.price.toFixed(2).replace('.', ',')}
                </p>
                <p className="text-gray-600 leading-relaxed">{product.description}</p>
              </div>

              {/* Size Selection */}
              <div>
                <h4 className="font-semibold text-gray-800 mb-3">Tamanho:</h4>
                <div className="flex flex-wrap gap-2">
                  {product.sizes.map((size) => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`px-4 py-2 border rounded-md transition-all ${
                        selectedSize === size
                          ? 'border-etec-orange bg-etec-orange text-white'
                          : 'border-gray-300 hover:border-etec-orange'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>

              {/* Color Selection */}
              <div>
                <h4 className="font-semibold text-gray-800 mb-3">Cor:</h4>
                <div className="flex flex-wrap gap-3">
                  {product.colors.map((color) => (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      className={`flex items-center space-x-2 px-3 py-2 border rounded-md transition-all ${
                        selectedColor === color
                          ? 'border-etec-orange bg-orange-50'
                          : 'border-gray-300 hover:border-etec-orange'
                      }`}
                    >
                      <div
                        className="w-5 h-5 rounded-full border"
                        style={{ backgroundColor: getColorStyle(color) }}
                      ></div>
                      <span className="text-sm">{color}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Quantity */}
              <div>
                <h4 className="font-semibold text-gray-800 mb-3">Quantidade:</h4>
                <div className="flex items-center space-x-3">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-10 h-10 flex items-center justify-center border border-gray-300 rounded-md hover:bg-gray-50"
                  >
                    -
                  </button>
                  <span className="w-16 text-center font-medium">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-10 h-10 flex items-center justify-center border border-gray-300 rounded-md hover:bg-gray-50"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Actions */}
              <div className="space-y-4">
                <button
                  onClick={handleAddToCart}
                  disabled={!product.inStock}
                  className="w-full bg-etec-orange text-white py-3 px-6 rounded-md hover:bg-orange-600 disabled:bg-gray-400 transition-colors font-medium flex items-center justify-center space-x-2"
                >
                  <ShoppingCart className="w-5 h-5" />
                  <span>{product.inStock ? 'Adicionar ao Carrinho' : 'Produto Esgotado'}</span>
                </button>

                <div className="flex space-x-4">
                  <button className="flex-1 border border-gray-300 text-gray-700 py-2 px-4 rounded-md hover:bg-gray-50 transition-colors flex items-center justify-center space-x-2">
                    <Heart className="w-5 h-5" />
                    <span>Favoritar</span>
                  </button>
                  <button className="flex-1 border border-gray-300 text-gray-700 py-2 px-4 rounded-md hover:bg-gray-50 transition-colors flex items-center justify-center space-x-2">
                    <Share2 className="w-5 h-5" />
                    <span>Compartilhar</span>
                  </button>
                </div>
              </div>

              {/* Product Info */}
              <div className="border-t pt-6 space-y-2 text-sm text-gray-600">
                <p><strong>Categoria:</strong> {product.category.charAt(0).toUpperCase() + product.category.slice(1)}</p>
                <p><strong>Disponibilidade:</strong> {product.inStock ? 'Em estoque' : 'Esgotado'}</p>
                <p><strong>Frete:</strong> Calculado no checkout</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}