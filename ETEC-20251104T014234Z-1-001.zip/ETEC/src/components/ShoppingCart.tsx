import React, { useState } from 'react';
import { X, Plus, Minus, Trash2, ShoppingBag } from 'lucide-react';
import { useCartStore } from '../stores/cartStore';
import { Checkout } from './Checkout';

export function ShoppingCart() {
  const { items, isOpen, toggleCart, updateQuantity, removeItem, getTotalItems, getTotalPrice } = useCartStore();
  const [showCheckout, setShowCheckout] = useState(false);

  console.log('Shopping cart rendered:', { itemCount: items.length, isOpen, total: getTotalPrice() });

  const handleCheckout = () => {
    console.log('Proceeding to checkout with items:', items);
    setShowCheckout(true);
    toggleCart();
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 z-50 overflow-hidden">
        <div className="absolute inset-0 bg-black bg-opacity-50" onClick={toggleCart}></div>
        
        <div className="absolute right-0 top-0 h-full w-full max-w-md bg-white shadow-xl">
          <div className="flex flex-col h-full">
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b">
              <h2 className="text-lg font-semibold text-gray-800 flex items-center">
                <ShoppingBag className="w-5 h-5 mr-2" />
                Carrinho ({getTotalItems()})
              </h2>
              <button
                onClick={toggleCart}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Cart Items */}
            <div className="flex-1 overflow-y-auto p-4">
              {items.length === 0 ? (
                <div className="text-center py-12">
                  <ShoppingBag className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">Seu carrinho está vazio</p>
                  <button
                    onClick={toggleCart}
                    className="mt-4 text-etec-orange hover:underline"
                  >
                    Continue comprando
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {items.map((item) => {
                    const itemKey = `${item.product.id}-${item.size}-${item.color}`;
                    return (
                      <div key={itemKey} className="bg-gray-50 rounded-lg p-4">
                        <div className="flex items-start space-x-3">
                          <img
                            src={item.product.image}
                            alt={item.product.name}
                            className="w-16 h-16 object-cover rounded-md"
                          />
                          <div className="flex-1 min-w-0">
                            <h3 className="font-medium text-gray-800 text-sm leading-tight">
                              {item.product.name}
                            </h3>
                            <p className="text-xs text-gray-600 mt-1">
                              Tamanho: {item.size} • Cor: {item.color}
                            </p>
                            <p className="text-sm font-semibold text-etec-orange mt-1">
                              R$ {item.product.price.toFixed(2).replace('.', ',')}
                            </p>
                          </div>
                          <button
                            onClick={() => removeItem(item.product.id, item.size, item.color)}
                            className="text-gray-400 hover:text-red-500 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                        
                        <div className="flex items-center justify-between mt-3">
                          <div className="flex items-center space-x-2">
                            <button
                              onClick={() => updateQuantity(item.product.id, item.size, item.color, item.quantity - 1)}
                              className="w-8 h-8 flex items-center justify-center border border-gray-300 rounded-md hover:bg-gray-100"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="w-8 text-center text-sm font-medium">{item.quantity}</span>
                            <button
                              onClick={() => updateQuantity(item.product.id, item.size, item.color, item.quantity + 1)}
                              className="w-8 h-8 flex items-center justify-center border border-gray-300 rounded-md hover:bg-gray-100"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                          <p className="font-semibold text-gray-800">
                            R$ {(item.product.price * item.quantity).toFixed(2).replace('.', ',')}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Footer */}
            {items.length > 0 && (
              <div className="border-t p-4 space-y-4">
                <div className="flex justify-between items-center text-lg font-semibold">
                  <span>Total:</span>
                  <span className="text-etec-orange">
                    R$ {getTotalPrice().toFixed(2).replace('.', ',')}
                  </span>
                </div>
                <button
                  onClick={handleCheckout}
                  className="w-full bg-etec-orange text-white py-3 rounded-md hover:bg-orange-600 transition-colors font-medium"
                >
                  Finalizar Compra
                </button>
                <button
                  onClick={toggleCart}
                  className="w-full border border-gray-300 text-gray-700 py-2 rounded-md hover:bg-gray-50 transition-colors"
                >
                  Continuar Comprando
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Checkout Modal */}
      <Checkout 
        isOpen={showCheckout} 
        onClose={() => setShowCheckout(false)} 
      />
    </>
  );
}