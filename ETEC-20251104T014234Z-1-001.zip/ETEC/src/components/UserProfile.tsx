import React, { useState } from 'react';
import { User, LogOut, Settings, Package, Heart, ChevronDown } from 'lucide-react';
import { useUserStore } from '../stores/userStore';

export function UserProfile() {
  const { user, isLoggedIn, isProfileOpen, login, logout, toggleProfile } = useUserStore();
  const [showLoginForm, setShowLoginForm] = useState(false);
  const [loginData, setLoginData] = useState({ email: '', password: '' });

  console.log('User profile rendered:', { isLoggedIn, user: user?.name, isProfileOpen });

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Attempting login with:', loginData.email);
    try {
      await login(loginData.email, loginData.password);
      setShowLoginForm(false);
      setLoginData({ email: '', password: '' });
    } catch (error) {
      console.error('Login failed:', error);
      alert('Erro no login. Verifique suas credenciais.');
    }
  };

  const handleLogout = () => {
    console.log('User logging out');
    logout();
    toggleProfile();
  };

  if (!isLoggedIn) {
    return (
      <div className="relative">
        <button
          onClick={() => setShowLoginForm(!showLoginForm)}
          className="flex items-center space-x-2 text-black hover:bg-black hover:text-etec-orange px-3 py-2 rounded-md transition-colors"
        >
          <User className="w-5 h-5" />
          <span className="hidden md:inline">Entrar</span>
        </button>

        {showLoginForm && (
          <div className="absolute right-0 top-full mt-2 w-80 bg-white rounded-lg shadow-xl border z-50">
            <div className="p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Fazer Login</h3>
              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    value={loginData.email}
                    onChange={(e) => setLoginData({ ...loginData, email: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-etec-orange focus:border-transparent"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                    Senha
                  </label>
                  <input
                    type="password"
                    id="password"
                    value={loginData.password}
                    onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-etec-orange focus:border-transparent"
                    required
                  />
                </div>
                <button
                  type="submit"
                  className="w-full bg-etec-orange text-white py-2 rounded-md hover:bg-orange-600 transition-colors font-medium"
                >
                  Entrar
                </button>
              </form>
              <p className="text-xs text-gray-500 mt-4">
                Demo: Use qualquer email e senha para entrar
              </p>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="relative">
      <button
        onClick={toggleProfile}
        className="flex items-center space-x-2 text-black hover:bg-black hover:text-etec-orange px-3 py-2 rounded-md transition-colors"
      >
        {user?.avatar ? (
          <img
            src={user.avatar}
            alt={user.name}
            className="w-8 h-8 rounded-full border-2 border-white"
          />
        ) : (
          <div className="w-8 h-8 bg-etec-purple rounded-full flex items-center justify-center">
            <span className="text-white text-sm font-semibold">
              {user?.name?.charAt(0)?.toUpperCase() || 'U'}
            </span>
          </div>
        )}
        <span className="hidden md:inline font-medium">{user?.name}</span>
        <ChevronDown className="w-4 h-4" />
      </button>

      {isProfileOpen && (
        <div className="absolute right-0 top-full mt-2 w-64 bg-white rounded-lg shadow-xl border z-50">
          <div className="p-4 border-b">
            <div className="flex items-center space-x-3">
              {user?.avatar ? (
                <img
                  src={user.avatar}
                  alt={user.name}
                  className="w-12 h-12 rounded-full"
                />
              ) : (
                <div className="w-12 h-12 bg-etec-purple rounded-full flex items-center justify-center">
                  <span className="text-white text-lg font-semibold">
                    {user?.name?.charAt(0)?.toUpperCase() || 'U'}
                  </span>
                </div>
              )}
              <div className="flex-1 min-w-0">
                <p className="font-medium text-gray-800 truncate">{user?.name}</p>
                <p className="text-sm text-gray-500 truncate">{user?.email}</p>
              </div>
            </div>
          </div>

          <div className="p-2">
            <button className="w-full flex items-center space-x-3 px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-md transition-colors">
              <User className="w-5 h-5" />
              <span>Meu Perfil</span>
            </button>
            <button className="w-full flex items-center space-x-3 px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-md transition-colors">
              <Package className="w-5 h-5" />
              <span>Meus Pedidos</span>
            </button>
            <button className="w-full flex items-center space-x-3 px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-md transition-colors">
              <Heart className="w-5 h-5" />
              <span>Favoritos</span>
            </button>
            <button className="w-full flex items-center space-x-3 px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-md transition-colors">
              <Settings className="w-5 h-5" />
              <span>Configurações</span>
            </button>
            <hr className="my-2" />
            <button
              onClick={handleLogout}
              className="w-full flex items-center space-x-3 px-3 py-2 text-red-600 hover:bg-red-50 rounded-md transition-colors"
            >
              <LogOut className="w-5 h-5" />
              <span>Sair</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}