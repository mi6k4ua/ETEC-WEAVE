import { Product } from '../types/product';

export const products: Product[] = [
  // Camisas
  {
    id: '1',
    name: 'Camisa Polo ETEC Masculina',
    description: 'Camisa polo oficial ETEC em algodão premium. Confortável e durável para uso diário.',
    price: 45.90,
    image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&h=400&fit=crop',
    category: 'camisas',
    sizes: ['P', 'M', 'G', 'GG'],
    colors: ['Laranja', 'Branco', 'Azul Marinho'],
    inStock: true,
  },
  {
    id: '2',
    name: 'Camisa Polo ETEC Feminina',
    description: 'Camisa polo feminina com corte anatômico. Material respirável e de alta qualidade.',
    price: 45.90,
    image: 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=400&h=400&fit=crop',
    category: 'camisas',
    sizes: ['PP', 'P', 'M', 'G', 'GG'],
    colors: ['Laranja', 'Branco', 'Rosa'],
    inStock: true,
  },
  {
    id: '3',
    name: 'Camiseta ETEC Básica',
    description: 'Camiseta básica com logo ETEC bordado. 100% algodão pré-encolhido.',
    price: 29.90,
    image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&h=400&fit=crop',
    category: 'camisas',
    sizes: ['P', 'M', 'G', 'GG', 'XGG'],
    colors: ['Laranja', 'Branco', 'Preto', 'Cinza'],
    inStock: true,
  },
  // Jaquetas
  {
    id: '4',
    name: 'Jaqueta ETEC Moletom',
    description: 'Jaqueta de moletom com capuz e logo ETEC bordado. Ideal para dias frios.',
    price: 89.90,
    image: 'https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=400&h=400&fit=crop',
    category: 'jaquetas',
    sizes: ['P', 'M', 'G', 'GG', 'XGG'],
    colors: ['Laranja', 'Preto', 'Cinza', 'Marinho'],
    inStock: true,
  },
  {
    id: '5',
    name: 'Jaqueta ETEC Tactel',
    description: 'Jaqueta corta-vento em tactel. Leve, resistente e confortável.',
    price: 75.90,
    image: 'https://images.unsplash.com/photo-1544966503-7cc5ac882d5f?w=400&h=400&fit=crop',
    category: 'jaquetas',
    sizes: ['P', 'M', 'G', 'GG'],
    colors: ['Laranja', 'Preto', 'Azul'],
    inStock: true,
  },
  // Calças
  {
    id: '6',
    name: 'Calça ETEC Social',
    description: 'Calça social em tecido de alta qualidade. Corte clássico e elegante.',
    price: 69.90,
    image: 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=400&h=400&fit=crop',
    category: 'calcas',
    sizes: ['36', '38', '40', '42', '44', '46', '48'],
    colors: ['Preto', 'Marinho', 'Cinza'],
    inStock: true,
  },
  {
    id: '7',
    name: 'Calça ETEC Jeans',
    description: 'Calça jeans com bordado ETEC. Tecido resistente e confortável.',
    price: 79.90,
    image: 'https://images.unsplash.com/photo-1542272604-787c3835535d?w=400&h=400&fit=crop',
    category: 'calcas',
    sizes: ['36', '38', '40', '42', '44', '46'],
    colors: ['Azul', 'Preto', 'Azul Claro'],
    inStock: true,
  },
  // Jalecos
  {
    id: '8',
    name: 'Jaleco ETEC Laboratório',
    description: 'Jaleco profissional para laboratórios. Tecido de alta qualidade e resistente.',
    price: 55.90,
    image: 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=400&h=400&fit=crop',
    category: 'jalecos',
    sizes: ['P', 'M', 'G', 'GG', 'XGG'],
    colors: ['Branco', 'Azul Claro'],
    inStock: true,
  },
  {
    id: '9',
    name: 'Jaleco ETEC Enfermagem',
    description: 'Jaleco específico para cursos de enfermagem. Confortável e prático.',
    price: 59.90,
    image: 'https://images.unsplash.com/photo-1559757175-0eb30cd8c063?w=400&h=400&fit=crop',
    category: 'jalecos',
    sizes: ['PP', 'P', 'M', 'G', 'GG'],
    colors: ['Branco', 'Rosa Claro', 'Azul Claro'],
    inStock: true,
  },
];

export const getProductsByCategory = (category: string) => {
  return products.filter(product => product.category === category);
};

export const getProductById = (id: string) => {
  return products.find(product => product.id === id);
};