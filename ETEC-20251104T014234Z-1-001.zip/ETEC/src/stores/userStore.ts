import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { User } from '../types/product';

interface UserStore {
  user: User | null;
  isLoggedIn: boolean;
  isProfileOpen: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  toggleProfile: () => void;
  updateProfile: (userData: Partial<User>) => void;
}

export const useUserStore = create<UserStore>()(
  persist(
    (set, get) => ({
      user: null,
      isLoggedIn: false,
      isProfileOpen: false,
      login: async (email: string, password: string) => {
        console.log('Attempting login:', { email });
        // Simulação de login - em produção, conectar com Supabase
        if (email && password) {
          const mockUser: User = {
            id: '1',
            name: email.split('@')[0],
            email,
            avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face'
          };
          set({ user: mockUser, isLoggedIn: true });
          console.log('Login successful:', mockUser);
        } else {
          throw new Error('Credenciais inválidas');
        }
      },
      logout: () => {
        console.log('User logged out');
        set({ user: null, isLoggedIn: false, isProfileOpen: false });
      },
      toggleProfile: () => {
        set((state) => ({ isProfileOpen: !state.isProfileOpen }));
      },
      updateProfile: (userData) => {
        console.log('Updating user profile:', userData);
        set((state) => ({
          user: state.user ? { ...state.user, ...userData } : null
        }));
      },
    }),
    {
      name: 'etec-weave-user',
    }
  )
);