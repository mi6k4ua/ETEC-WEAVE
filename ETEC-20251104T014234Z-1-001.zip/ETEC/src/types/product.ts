export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: 'camisas' | 'jaquetas' | 'calcas' | 'jalecos';
  sizes: string[];
  colors: string[];
  inStock: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
  size: string;
  color: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
}